/**
 * Interview Analyzer — script.js
 *
 * Fixes applied vs original:
 *  1. Blob URL memory leak — revokeObjectURL() called before each new assignment.
 *  2. Same-file re-select — fileInput.value reset after analysis so change fires again.
 *  3. Double-submit guard — btnAnalyze disabled flag checked at entry.
 *  4. Robust JSON parsing — wraps JSON.parse in try/catch with fallback message.
 *  5. Drag-and-drop — full dragover/dragleave/drop support on the drop zone.
 *  6. Animated score ring + grade labels.
 *  7. Tooltip on stat cards.
 *  8. Loader cycling messages.
 */

/* ── Element refs ── */
const videoInput    = document.getElementById("videoInput");
const dropZone      = document.getElementById("dropZone");
const previewWrap   = document.getElementById("previewWrap");
const videoPreview  = document.getElementById("videoPreview");
const metaName      = document.getElementById("metaName");
const metaSize      = document.getElementById("metaSize");
const metaType      = document.getElementById("metaType");
const btnClear      = document.getElementById("btnClear");
const btnAnalyze    = document.getElementById("btnAnalyze");
const btnAgain      = document.getElementById("btnAgain");
const loaderWrap    = document.getElementById("loaderWrap");
const loaderText    = document.getElementById("loaderText");
const errorWrap     = document.getElementById("errorWrap");
const errorMsg      = document.getElementById("errorMsg");
const resultsSection = document.getElementById("resultsSection");
const tooltip       = document.getElementById("tooltip");

/* Score ring elements */
const scoreFill     = document.getElementById("scoreFill");
const scoreNum      = document.getElementById("scoreNum");
const scoreGrade    = document.getElementById("scoreGrade");
const scoreDesc     = document.getElementById("scoreDesc");

/* Stats */
const statWpm       = document.getElementById("statWpm");
const statFiller    = document.getElementById("statFiller");
const statFace      = document.getElementById("statFace");
const statPauses    = document.getElementById("statPauses");
const statSentiment = document.getElementById("statSentiment");
const statDuration  = document.getElementById("statDuration");

/* Transcript + tips */
const transcriptText   = document.getElementById("transcriptText");
const wordCountBadge   = document.getElementById("wordCountBadge");
const tipsList         = document.getElementById("tipsList");

/* ── State ── */
let currentBlobUrl = null;   // FIX 1: track blob URL for revocation
let isAnalyzing    = false;  // FIX 3: double-submit guard
let loaderInterval = null;

/* ── Helpers ── */

function formatSize(bytes) {
  if (!bytes) return "0 KB";
  const mb = bytes / (1024 * 1024);
  return mb >= 1 ? `${mb.toFixed(2)} MB` : `${(bytes / 1024).toFixed(1)} KB`;
}

function formatDuration(secs) {
  if (!secs) return "0 s";
  const m = Math.floor(secs / 60);
  const s = Math.round(secs % 60);
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

function showEl(el)  { el.hidden = false; }
function hideEl(el)  { el.hidden = true; }

function showError(msg) {
  hideEl(loaderWrap);
  errorMsg.textContent = msg;
  showEl(errorWrap);
  errorWrap.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function clearError() {
  hideEl(errorWrap);
  errorMsg.textContent = "";
}

/* ── Loader cycling messages ── */
const LOADER_MESSAGES = [
  "Extracting audio…",
  "Transcribing speech…",
  "Analyzing tone and pace…",
  "Detecting face presence…",
  "Calculating confidence score…",
  "Preparing your report…",
];

function startLoader() {
  showEl(loaderWrap);
  loaderText.textContent = LOADER_MESSAGES[0];
  let i = 1;
  loaderInterval = setInterval(() => {
    loaderText.textContent = LOADER_MESSAGES[Math.min(i, LOADER_MESSAGES.length - 1)];
    i++;
  }, 3500);
}

function stopLoader() {
  clearInterval(loaderInterval);
  loaderInterval = null;
  hideEl(loaderWrap);
}

/* ── Score ring animation ── */
const RING_CIRCUMFERENCE = 2 * Math.PI * 68; // ≈ 427

const GRADE_MAP = [
  { min: 85, label: "Excellent",    color: "#4ddc8f", desc: "Your delivery, pacing, and presence are all strong. You're interview-ready." },
  { min: 70, label: "Good",         color: "#d4f244", desc: "Solid performance with a few areas to refine. Practice the tips below." },
  { min: 55, label: "Developing",   color: "#ffb547", desc: "You're on the right track. Focus on the coaching tips to improve quickly." },
  { min:  0, label: "Needs work",   color: "#ff5f5f", desc: "Significant room to improve. Regular practice will make a big difference." },
];

function animateScore(score) {
  const grade = GRADE_MAP.find(g => score >= g.min) || GRADE_MAP[GRADE_MAP.length - 1];
  const offset = RING_CIRCUMFERENCE * (1 - score / 100);

  scoreGrade.textContent = grade.label;
  scoreGrade.style.color = grade.color;
  scoreDesc.textContent  = grade.desc;
  scoreFill.style.stroke = grade.color;

  /* Animate number */
  let current = 0;
  const step  = Math.ceil(score / 60);
  const timer = setInterval(() => {
    current = Math.min(current + step, score);
    scoreNum.textContent = current;
    if (current >= score) clearInterval(timer);
  }, 20);

  /* Animate ring */
  requestAnimationFrame(() => {
    scoreFill.style.strokeDashoffset = offset;
  });
}

/* ── File selection ── */

function handleFile(file) {
  if (!file) return;

  clearError();
  hideEl(resultsSection);

  /* FIX 1: revoke previous blob URL before creating a new one */
  if (currentBlobUrl) {
    URL.revokeObjectURL(currentBlobUrl);
    currentBlobUrl = null;
  }

  metaName.textContent = file.name;
  metaSize.textContent = formatSize(file.size);
  metaType.textContent = file.type || "video/*";

  currentBlobUrl   = URL.createObjectURL(file);
  videoPreview.src = currentBlobUrl;
  showEl(previewWrap);
  previewWrap.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

videoInput.addEventListener("change", () => {
  const file = videoInput.files[0];
  if (file) handleFile(file);
});

/* ── Clear / reset ── */

function resetToUpload() {
  /* FIX 2: reset input value so re-selecting the same file fires 'change' again */
  videoInput.value = "";

  if (currentBlobUrl) {
    URL.revokeObjectURL(currentBlobUrl);
    currentBlobUrl = null;
  }
  videoPreview.removeAttribute("src");
  videoPreview.load();

  hideEl(previewWrap);
  hideEl(resultsSection);
  clearError();

  /* Reset score ring */
  scoreFill.style.strokeDashoffset = RING_CIRCUMFERENCE;
  scoreNum.textContent = "—";
  scoreGrade.textContent = "";
  scoreDesc.textContent  = "";
}

btnClear.addEventListener("click", resetToUpload);
btnAgain.addEventListener("click", resetToUpload);

/* ── Drag and drop ── */

["dragenter", "dragover"].forEach(evt => {
  dropZone.addEventListener(evt, e => {
    e.preventDefault();
    dropZone.classList.add("drag-over");
  });
});

["dragleave", "dragend", "drop"].forEach(evt => {
  dropZone.addEventListener(evt, e => {
    e.preventDefault();
    dropZone.classList.remove("drag-over");
  });
});

dropZone.addEventListener("drop", e => {
  const file = e.dataTransfer?.files?.[0];
  if (file && file.type.startsWith("video/")) {
    handleFile(file);
    /* Sync the file input so FormData can read it */
    const dt = new DataTransfer();
    dt.items.add(file);
    videoInput.files = dt.files;
  } else if (file) {
    showError("Please drop a video file.");
  }
});

/* ── Analysis ── */

btnAnalyze.addEventListener("click", async () => {
  /* FIX 3: guard against double-submit */
  if (isAnalyzing) return;

  const file = videoInput.files[0];
  if (!file) {
    showError("Please select a video file first.");
    return;
  }

  isAnalyzing = true;
  btnAnalyze.disabled = true;
  clearError();
  hideEl(resultsSection);
  startLoader();

  const formData = new FormData();
  formData.append("video", file);

  try {
    const response = await fetch("/analyze", {
      method: "POST",
      body: formData,
    });

    const rawText = await response.text();

    /* FIX 4: safe JSON parse */
    let data;
    try {
      data = JSON.parse(rawText);
    } catch {
      throw new Error("Server returned an unexpected response. Check the Flask console for details.");
    }

    if (!response.ok || data.error) {
      throw new Error(data.error || `Server error (${response.status}).`);
    }

    renderResults(data);

  } catch (err) {
    showError(err.message || "Something went wrong. Please try again.");
    console.error("[Interview Analyzer]", err);
  } finally {
    stopLoader();
    isAnalyzing    = false;
    btnAnalyze.disabled = false;

    /* FIX 2: reset file input so re-selecting same file works */
    videoInput.value = "";
  }
});

/* ── Render results ── */

function renderResults(data) {
  const sp = data.speech_analysis;
  const vd = data.video_analysis;

  /* Score */
  animateScore(data.confidence_score);

  /* Stats */
  statWpm.textContent       = sp.wpm > 0 ? `${sp.wpm}` : "—";
  statFiller.textContent    = sp.filler_count;
  statFace.textContent      = `${vd.face_presence_percent}%`;
  statPauses.textContent    = sp.pause_count;
  statSentiment.textContent = sp.sentiment >= 0 ? `+${sp.sentiment}` : `${sp.sentiment}`;
  statDuration.textContent  = formatDuration(sp.duration);

  /* Colour-code sentiment */
  const sentVal = parseFloat(sp.sentiment);
  statSentiment.style.color =
    sentVal > 0.1  ? "var(--good)"  :
    sentVal < -0.1 ? "var(--danger)" : "var(--text)";

  /* Transcript */
  transcriptText.textContent =
    sp.transcript ? `"${sp.transcript}"` : "No speech was detected in this video.";
  wordCountBadge.textContent =
    `${sp.word_count} word${sp.word_count !== 1 ? "s" : ""}`;

  /* Tips */
  tipsList.innerHTML = "";
  data.tips.forEach((tip, i) => {
    const li = document.createElement("li");
    li.textContent = tip;
    li.style.animationDelay = `${i * 80}ms`;
    tipsList.appendChild(li);
  });

  stopLoader();
  showEl(resultsSection);
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ── Tooltip on stat cards ── */

document.querySelectorAll(".stat-card[data-tip]").forEach(card => {
  card.addEventListener("mouseenter", e => {
    tooltip.textContent = card.dataset.tip;
    tooltip.classList.add("visible");
    tooltip.setAttribute("aria-hidden", "false");
    positionTooltip(e);
  });
  card.addEventListener("mousemove", positionTooltip);
  card.addEventListener("mouseleave", () => {
    tooltip.classList.remove("visible");
    tooltip.setAttribute("aria-hidden", "true");
  });
});

function positionTooltip(e) {
  const pad = 12;
  let x = e.clientX + pad;
  let y = e.clientY - tooltip.offsetHeight - pad;
  /* Keep inside viewport */
  if (x + tooltip.offsetWidth > window.innerWidth - pad) {
    x = e.clientX - tooltip.offsetWidth - pad;
  }
  if (y < pad) y = e.clientY + pad;
  tooltip.style.left = `${x}px`;
  tooltip.style.top  = `${y}px`;
}