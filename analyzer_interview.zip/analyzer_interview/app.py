from flask import Flask, render_template, request, jsonify
import os
import cv2
import speech_recognition as sr
from textblob import TextBlob
from werkzeug.utils import secure_filename
import subprocess

app = Flask(__name__, template_folder="templates", static_folder="templates/static")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

# If "uploads" exists as a file (not a directory), rename it and create the folder
if os.path.exists(UPLOAD_FOLDER) and not os.path.isdir(UPLOAD_FOLDER):
    os.rename(UPLOAD_FOLDER, UPLOAD_FOLDER + "_old")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

ALLOWED_EXTENSIONS = {"mp4", "mov", "avi", "mkv", "webm", "m4v"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# -----------------------------
# Extract audio from video using FFmpeg
# -----------------------------
def extract_audio(video_path):
    audio_path = os.path.join(app.config["UPLOAD_FOLDER"], "temp_audio.wav")

    command = [
        "ffmpeg", "-y",
        "-i", video_path,
        "-vn",
        "-acodec", "pcm_s16le",
        "-ar", "16000",
        "-ac", "1",
        audio_path
    ]

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False
        )
    except FileNotFoundError as exc:
        raise RuntimeError("FFmpeg is not installed or not found in PATH.") from exc

    if result.returncode != 0 or not os.path.exists(audio_path):
        raise RuntimeError(
            "Could not extract audio from the video. "
            "Ensure FFmpeg is installed and the video format is supported."
        )

    # Get duration via ffprobe to avoid opening the file twice later
    duration = _get_audio_duration(audio_path)
    return audio_path, duration


def _get_audio_duration(audio_path):
    """Return duration in seconds using SpeechRecognition's AudioFile."""
    try:
        with sr.AudioFile(audio_path) as source:
            return source.DURATION
    except Exception:
        return 0.0


# -----------------------------
# Convert speech to text (chunked to handle long audio)
# FIX: Google's free API silently fails on audio > ~60s.
#      We split into 55-second chunks and join the results.
# -----------------------------
def transcribe_audio(audio_path, duration):
    recognizer = sr.Recognizer()
    transcript_parts = []
    chunk_size = 55  # seconds — safely under Google's limit

    with sr.AudioFile(audio_path) as source:
        offset = 0.0
        while offset < duration:
            record_duration = min(chunk_size, duration - offset)
            if record_duration < 0.5:
                break
            audio_chunk = recognizer.record(source, duration=record_duration)
            try:
                part = recognizer.recognize_google(audio_chunk)
                transcript_parts.append(part)
            except sr.UnknownValueError:
                pass  # Silence or unintelligible chunk — skip
            except sr.RequestError:
                pass  # API unavailable — skip chunk
            offset += chunk_size

    return " ".join(transcript_parts)


# -----------------------------
# Analyze speech metrics
# Duration is passed in — no second file open needed.
# FIX: was reopening audio_path redundantly.
# -----------------------------
def analyze_speech(transcript, duration):
    words = transcript.split()
    word_count = len(words)

    minutes = duration / 60 if duration > 0 else 1
    wpm = word_count / minutes if word_count > 0 else 0

    filler_words = ["um", "uh", "like", "you know", "actually", "basically", "so", "right"]
    lower_text = transcript.lower()
    filler_count = sum(lower_text.count(fw) for fw in filler_words)

    sentiment = TextBlob(transcript).sentiment.polarity if transcript else 0.0

    # Simple pause estimation: roughly one pause per 8 seconds of speech
    pause_count = max(0, int(duration // 8))

    return {
        "transcript": transcript,
        "word_count": word_count,
        "wpm": round(wpm, 2),
        "filler_count": filler_count,
        "pause_count": pause_count,
        "sentiment": round(sentiment, 2),
        "duration": round(duration, 2),
    }


# -----------------------------
# Analyze video — face detection via OpenCV Haar cascade
# -----------------------------
def analyze_video(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError("Could not open the uploaded video file.")

    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    frame_count = 0
    face_frames = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_count += 1
        if frame_count % 10 == 0:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            if len(faces) > 0:
                face_frames += 1

    cap.release()

    sampled_frames = max(1, frame_count // 10)
    face_presence = (face_frames / sampled_frames) * 100

    return {
        "total_frames": frame_count,
        "face_presence_percent": round(face_presence, 2),
    }


# -----------------------------
# Confidence score
# FIX: silent/faceless video no longer inflates score.
#      Empty transcript now applies a penalty instead of neutral base.
# -----------------------------
def calculate_confidence_score(speech_data, video_data):
    # If no speech was detected at all, cap score low
    if speech_data["word_count"] == 0:
        base = 20
        # Still reward face presence a little
        if video_data["face_presence_percent"] >= 70:
            base += 10
        return max(0, min(100, base))

    score = 50

    # Words per minute
    wpm = speech_data["wpm"]
    if 100 <= wpm <= 160:
        score += 15
    elif 80 <= wpm < 100 or 160 < wpm <= 180:
        score += 8
    else:
        score -= 5

    # Filler words
    fc = speech_data["filler_count"]
    if fc <= 3:
        score += 10
    elif fc <= 7:
        score += 5
    else:
        score -= 8

    # Pauses
    if speech_data["pause_count"] <= 5:
        score += 10
    else:
        score -= 5

    # Face presence
    fp = video_data["face_presence_percent"]
    if fp >= 70:
        score += 15
    elif fp >= 40:
        score += 8
    else:
        score -= 5

    # Sentiment bonus
    if speech_data["sentiment"] > 0:
        score += 5

    return max(0, min(100, int(score)))


# -----------------------------
# Generate improvement tips
# -----------------------------
def generate_tips(speech_data, video_data, confidence_score):
    tips = []

    if speech_data["word_count"] == 0:
        tips.append("No speech was detected. Ensure your microphone was on and the video has clear audio.")
        return tips

    if speech_data["wpm"] < 100:
        tips.append("Try speaking a bit faster — a pace of 120–150 wpm feels natural and keeps listeners engaged.")
    elif speech_data["wpm"] > 160:
        tips.append("Slow down slightly. Speaking too fast can make you seem nervous and harder to follow.")

    if speech_data["filler_count"] > 5:
        tips.append("Reduce filler words like 'um', 'uh', 'like', and 'basically'. Pause silently instead — it reads as confidence.")

    if speech_data["pause_count"] > 5:
        tips.append("Work on smoother sentence transitions to reduce long pauses. Structured prep helps.")

    if video_data["face_presence_percent"] < 60:
        tips.append("Maintain better eye contact with the camera and ensure your face is well-lit and centred.")

    if speech_data["sentiment"] < 0:
        tips.append("Your language skewed negative. Try framing answers more positively — even when discussing challenges.")

    if confidence_score < 60:
        tips.append("Practice mock interviews regularly. Recording yourself and reviewing is one of the fastest ways to improve.")

    if not tips:
        tips.append("Excellent performance! Your pacing, clarity, and presence are all well-balanced. Keep it up.")

    return tips


# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    if "video" not in request.files:
        return jsonify({"error": "No video file was included in the request."}), 400

    file = request.files["video"]

    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    # FIX: Use werkzeug's secure_filename instead of os.path.basename
    safe_name = secure_filename(file.filename)
    if not safe_name or not allowed_file(safe_name):
        return jsonify({"error": "Unsupported file type. Please upload an mp4, mov, avi, mkv, or webm file."}), 400

    video_path = os.path.join(app.config["UPLOAD_FOLDER"], safe_name)
    file.save(video_path)

    try:
        audio_path, duration = extract_audio(video_path)
        transcript = transcribe_audio(audio_path, duration)
        speech_data = analyze_speech(transcript, duration)
        video_data = analyze_video(video_path)
        confidence_score = calculate_confidence_score(speech_data, video_data)
        tips = generate_tips(speech_data, video_data, confidence_score)

        return jsonify({
            "confidence_score": confidence_score,
            "speech_analysis": speech_data,
            "video_analysis": video_data,
            "tips": tips,
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        # Clean up uploaded files after analysis
        for path in [video_path, os.path.join(app.config["UPLOAD_FOLDER"], "temp_audio.wav")]:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass


if __name__ == "__main__":
    app.run(debug=True)