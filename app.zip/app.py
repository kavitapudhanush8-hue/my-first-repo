from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import requests
import uuid
import os
import time
from threading import Lock
import random
import base64
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Groq API configuration
API_CONFIG = {
    "model_name": "llama-3.3-70b-versatile",
    "api_key": "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",
    "base_url": "https://api.groq.com/openai/v1"
}

# Twilio configuration (optional - for actual SMS sending)
TWILIO_ENABLED = False
TWILIO_CONFIG = {
    "account_sid": os.environ.get("TWILIO_ACCOUNT_SID", ""),
    "auth_token": os.environ.get("TWILIO_AUTH_TOKEN", ""),
    "phone_number": os.environ.get("TWILIO_PHONE_NUMBER", "")
}

# Enable Twilio if credentials are provided
if all(TWILIO_CONFIG.values()):
    try:
        from twilio.rest import Client
        twilio_client = Client(TWILIO_CONFIG["account_sid"], TWILIO_CONFIG["auth_token"])
        TWILIO_ENABLED = True
        print("✓ Twilio SMS enabled")
    except ImportError:
        print("⚠ Twilio library not installed. SMS will use system SMS app.")
        print("  To enable: pip install twilio")
else:
    print("⚠ Twilio not configured. SMS will use system SMS app.")
    print("  To enable SMS: Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER")

# System prompts
PANIC_SYSTEM_PROMPT = """You are an emergency safety assistant for women. When a woman presses PANIC, provide IMMEDIATE, ACTIONABLE safety advice.

Focus on:
1. Immediate actions to stay safe RIGHT NOW
2. How to assess the situation quickly
3. Practical steps to get to safety
4. What to do while waiting for help

Be DIRECT and CONCISE. No tables. Give clear bullet points with urgent actions.

Example format:
🚨 STAY CALM - You can handle this

**Right Now:**
• Keep walking at a steady pace, don't run unless pursued
• Head toward lit areas with people
• Keep your phone in hand, ready to call
• Don't look back - face forward with confidence

**If followed:**
• Cross the street or change direction
• Enter a public place (store, restaurant, police station)
• Call emergency services (112) immediately
• Activate your phone's emergency mode

**Trust your instincts** - If something feels wrong, it is."""

SYSTEM_PROMPT = """You are a helpful assistant focused on women's safety. 
Provide helpful, accurate, and supportive information related to women's safety concerns, 
women's health, women's rights, and empowerment. Be respectful and empathetic.

Guide conversations toward women's safety topics when needed."""

# Storage
conversation_histories = {}
panic_photos = {}  # Store photos by session_id
last_request_time = 0
MIN_REQUEST_INTERVAL = 2
request_lock = Lock()
api_available = True
last_api_failure_time = 0
COOLDOWN_PERIOD = 60

def send_sms(to_number, message):
    """Send SMS via Twilio or system SMS app"""
    if TWILIO_ENABLED:
        try:
            message_obj = twilio_client.messages.create(
                body=message,
                from_=TWILIO_CONFIG["phone_number"],
                to=to_number
            )
            print(f"✓ SMS sent via Twilio to {to_number}: {message_obj.sid}")
            return {"success": True, "method": "twilio", "sid": message_obj.sid}
        except Exception as e:
            print(f"✗ Twilio SMS failed: {str(e)}")
            return {"success": False, "error": str(e)}
    else:
        # Log that SMS would be sent via system app
        print(f"📱 SMS (system app) to {to_number}: {message[:50]}...")
        return {"success": True, "method": "system_app"}

def is_womens_safety_related(message):
    """Check if message is women's safety related"""
    message_lower = message.lower()
    
    allowed = ['hello', 'hi', 'hey', 'help', 'emergency', 'panic', 'danger', 'sos']
    unrelated = ['sports', 'game', 'movie', 'music', 'recipe', 'weather']
    safety_keywords = ['women', 'safety', 'harassment', 'abuse', 'violence', 
                       'self-defense', 'emergency', 'stalking', 'alone', 'night']
    
    for word in allowed:
        if word in message_lower:
            return True
    
    for word in unrelated:
        if word in message_lower:
            return False
    
    for word in safety_keywords:
        if word in message_lower:
            return True
    
    return True

def get_conversation_history(session_id, is_panic=False):
    """Get or create conversation history"""
    if session_id not in conversation_histories:
        conversation_histories[session_id] = [{
            "role": "system",
            "content": PANIC_SYSTEM_PROMPT if is_panic else SYSTEM_PROMPT
        }]
    return conversation_histories[session_id]

def call_groq_api(user_message, session_id, is_panic=False):
    """Call Groq API"""
    global last_request_time, api_available, last_api_failure_time
    
    if not is_panic and not is_womens_safety_related(user_message):
        return "I'm designed to help with women's safety. Is there a safety concern I can assist you with?"
    
    current_time = time.time()
    if not api_available and (current_time - last_api_failure_time) < COOLDOWN_PERIOD:
        return get_fallback_response(user_message, is_panic)
    
    if not api_available:
        api_available = True
    
    try:
        with request_lock:
            current_time = time.time()
            time_since = current_time - last_request_time
            if time_since < MIN_REQUEST_INTERVAL:
                time.sleep(MIN_REQUEST_INTERVAL - time_since)
            last_request_time = time.time()
        
        conversation = get_conversation_history(session_id, is_panic)
        conversation.append({"role": "user", "content": user_message})
        
        response = requests.post(
            f"{API_CONFIG['base_url']}/chat/completions",
            headers={
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {API_CONFIG['api_key']}"
            },
            json={
                "model": API_CONFIG["model_name"],
                "messages": conversation,
                "max_tokens": 1024,
                "temperature": 0.5 if is_panic else 0.7
            },
            timeout=15
        )
        
        if response.status_code == 429:
            api_available = False
            last_api_failure_time = time.time()
            return get_fallback_response(user_message, is_panic)
        elif response.status_code != 200:
            raise Exception(f"API failed: {response.status_code}")
        
        data = response.json()
        message = data["choices"][0]["message"]["content"]
        conversation.append({"role": "assistant", "content": message})
        
        return message
        
    except Exception as e:
        print(f"Error: {str(e)}")
        api_available = False
        last_api_failure_time = time.time()
        return get_fallback_response(user_message, is_panic)

def get_fallback_response(user_message, is_panic=False):
    """Fallback when API unavailable"""
    message_lower = user_message.lower()
    
    if is_panic or any(w in message_lower for w in ["panic", "emergency", "help", "danger"]):
        return """🚨 EMERGENCY PROTOCOL

**Right Now:**
• Call emergency services: 112 (India) or 911
• Keep moving toward populated, lit areas
• Don't look back - walk confidently
• Keep phone in hand, ready

**If Being Followed:**
• Cross the street or change direction
• Enter any public place immediately
• Shout loudly if needed: "Back off!"
• Call your emergency contacts

**Stay calm. You can handle this. Help is available.**"""
    
    elif any(w in message_lower for w in ["harassment", "uncomfortable"]):
        return """**If Experiencing Harassment:**
• Document everything (dates, times, details)
• Tell someone you trust
• Report to authorities
• Block/avoid the harasser
• Your feelings are valid

NCW Helpline: 7827170170"""
    
    elif any(w in message_lower for w in ["travel", "alone", "night"]):
        return """**Safety When Traveling Alone:**
• Share your route and ETA
• Stick to well-lit, busy areas
• Keep phone charged
• Trust your instincts
• Have emergency contacts ready"""
    
    else:
        return "I'm experiencing technical difficulties. For urgent help, call 112 or use the emergency features."

# Load HTML
HTML_TEMPLATE = open('index.html', 'r', encoding='utf-8').read() if os.path.exists('index.html') else ""

@app.route('/')
def index():
    if HTML_TEMPLATE:
        return render_template_string(HTML_TEMPLATE)
    return "<h1>Template not found</h1>", 404

@app.route('/favicon.ico')
def favicon():
    return '', 204

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat"""
    try:
        data = request.json
        user_message = data.get('message', '')
        session_id = data.get('session_id', str(uuid.uuid4()))
        
        if not user_message:
            return jsonify({"error": "No message"}), 400
        
        is_panic = 'EMERGENCY' in user_message and 'PANIC' in user_message
        response = call_groq_api(user_message, session_id, is_panic)
        
        return jsonify({"reply": response, "session_id": session_id})
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({"error": "Internal error", "reply": get_fallback_response("", False)}), 500

@app.route('/api/panic', methods=['POST'])
def panic():
    """Handle PANIC"""
    try:
        data = request.json
        user_id = data.get('userId', 'unknown')
        coords = data.get('coords', {})
        contacts = data.get('contacts', [])
        
        print(f"🚨 PANIC by {user_id}")
        print(f"📍 Location: {coords}")
        print(f"📞 Contacts: {len(contacts)}")
        
        # Send SMS to contacts if Twilio enabled
        if TWILIO_ENABLED and coords:
            lat = coords.get('latitude')
            lon = coords.get('longitude')
            location_url = f"https://maps.google.com/?q={lat},{lon}"
            message = f"🚨 EMERGENCY! I need help urgently. My location: {location_url}"
            
            for contact in contacts:
                send_sms(contact['phone'], message)
        
        return jsonify({"success": True, "timestamp": time.time()})
        
    except Exception as e:
        print(f"Panic error: {str(e)}")
        return jsonify({"error": "Failed"}), 500

@app.route('/api/save-photo', methods=['POST'])
def save_photo():
    """Save panic photo"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'unknown')
        photo_data = data.get('photo', '')
        timestamp = data.get('timestamp', datetime.now().isoformat())
        
        if session_id not in panic_photos:
            panic_photos[session_id] = []
        
        photo_entry = {
            'id': str(uuid.uuid4()),
            'data': photo_data,
            'timestamp': timestamp
        }
        
        panic_photos[session_id].append(photo_entry)
        
        print(f"📷 Photo saved for {session_id} (Total: {len(panic_photos[session_id])})")
        
        return jsonify({
            "success": True, 
            "photoId": photo_entry['id'],
            "totalPhotos": len(panic_photos[session_id])
        })
        
    except Exception as e:
        print(f"Photo save error: {str(e)}")
        return jsonify({"error": "Failed to save photo"}), 500

@app.route('/api/get-photos', methods=['POST'])
def get_photos():
    """Get all panic photos for session"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'unknown')
        
        photos = panic_photos.get(session_id, [])
        
        return jsonify({
            "success": True,
            "photos": photos,
            "count": len(photos)
        })
        
    except Exception as e:
        print(f"Get photos error: {str(e)}")
        return jsonify({"error": "Failed to retrieve photos"}), 500

@app.route('/api/delete-photos', methods=['POST'])
def delete_photos():
    """Delete all panic photos for session"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'unknown')
        
        if session_id in panic_photos:
            count = len(panic_photos[session_id])
            del panic_photos[session_id]
            print(f"🗑️ Deleted {count} photos for {session_id}")
            
        return jsonify({"success": True, "deleted": count if session_id in panic_photos else 0})
        
    except Exception as e:
        print(f"Delete photos error: {str(e)}")
        return jsonify({"error": "Failed to delete photos"}), 500

@app.route('/api/sos', methods=['POST'])
def sos():
    """Handle SOS with location"""
    try:
        data = request.json
        user_id = data.get('userId', 'unknown')
        coords = data.get('coords', {})
        contacts = data.get('contacts', [])
        
        print(f"🆘 SOS by {user_id}")
        print(f"📍 Location: {coords}")
        print(f"📞 Contacts: {len(contacts)}")
        
        lat = coords.get('latitude')
        lon = coords.get('longitude')
        location_url = f"https://maps.google.com/?q={lat},{lon}"
        
        # Send SMS to contacts if Twilio enabled
        if TWILIO_ENABLED:
            message = f"🚨 EMERGENCY! I need help urgently. My location: {location_url}"
            
            for contact in contacts:
                result = send_sms(contact['phone'], message)
                print(f"  → {contact['name']}: {result}")
        
        return jsonify({
            "success": True,
            "location_url": location_url,
            "sms_method": "twilio" if TWILIO_ENABLED else "system_app",
            "timestamp": time.time()
        })
        
    except Exception as e:
        print(f"SOS error: {str(e)}")
        return jsonify({"error": "Failed to send SOS"}), 500

@app.route('/reset', methods=['POST'])
def reset_conversation():
    """Reset conversation"""
    try:
        data = request.json
        session_id = data.get('session_id')
        
        if session_id and session_id in conversation_histories:
            del conversation_histories[session_id]
        
        return jsonify({"success": True})
        
    except Exception as e:
        print(f"Reset error: {str(e)}")
        return jsonify({"error": "Failed"}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🛡️ Women Safety Chatbot Server")
    print("=" * 60)
    print(f"Frontend: http://localhost:5000")
    print(f"SMS Method: {'Twilio' if TWILIO_ENABLED else 'System SMS App'}")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5000)